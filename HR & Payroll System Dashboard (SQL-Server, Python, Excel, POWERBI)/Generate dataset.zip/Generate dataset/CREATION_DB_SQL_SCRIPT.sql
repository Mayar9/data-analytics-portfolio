--USE EmployeeCaseStudy
--DROP DATABASE HR_PAYROLL_DWH;
CREATE DATABASE HR_PAYROLL;
USE HR_PAYROLL;

--1. employee Table 
--2. department Table 
--3. jobs Table
--4. projects Table 
--5. attendance table 
--6. leave table 
--7. payroll table 
--8. evaluations table 
--9. benefits table 
--10. empEmergency table 
--11. programTrainings table
--12. evaluations_comments table 
--13. employees_evaluations table 
--14. employees_programs table 
--15. employees_projects table 


--1. start with independent tables has no foreign keys like programTraings, projects
--2. lookup/dim tables like departments, jobs
--3. fact tables like attendance, leave, payroll, evaluations
--4. M-to-M bridge tables like employees_programs, employees_projects, employees_evaluations
--5. foreign keys creation


--dim tables
CREATE TABLE programTrainings( --"training_id", "training_title", "training_desc", "provider", "start_date", "end_date"
	training_id INT PRIMARY KEY,
	training_title NVARCHAR(100),
	training_desc NVARCHAR(200),	
	provider NVARCHAR(100),
	start_date DATE,
	end_date DATE
	);
CREATE TABLE projects(
	project_id INT PRIMARY KEY,	
	project_name NVARCHAR(100),	
	project_theme NVARCHAR(100),
	project_desc NVARCHAR(200),
	budget DECIMAL,	
	start_date DATE,	
	end_date DATE
	);

	-- to rebuild projects table 
DROP TABLE employees_projects;
DROP TABLE projects;
CREATE TABLE departments(
	dept_id INT PRIMARY KEY,	
	dept_name NVARCHAR(50),	
	location NVARCHAR(50),	
	creation_date DATE,	
	head_id INT NULL
	--FOREIGN KEY (head_id) REFERENCES employees(supervisor_id)
	);
CREATE TABLE jobs(-- job_id	job_title	job_desc	dept_id	job_level	hourly_rate
	job_id INT PRIMARY KEY,	
	job_title NVARCHAR(100),	
	job_desc NVARCHAR(100),
	dept_id INT NULL,
	job_level NVARCHAR(50),
	hourly_rate DECIMAL
	--FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
	);

CREATE TABLE employees(
	employee_id INT PRIMARY KEY, 
	full_name NVARCHAR(100),
	phone_number NVARCHAR(50),	
	birthdate DATE,	
	national_id NVARCHAR(50),	
	email NVARCHAR(100),	
	gender NVARCHAR(20),	
	current_status NVARCHAR(20),	
	city NVARCHAR(50),	
	state NVARCHAR(50),	
	zip_code INT,	
	street_address NVARCHAR(200),	
	dept_id INT NULL,	
	job_id INT NULL,	
	supervisor_id INT NULL
	--FOREIGN KEY (dept_id) REFERENCES  departments(dept_id),
	--FOREIGN KEY (job_id) REFERENCES jobs(job_id),
	--FOREIGN KEY (supervisor_id) REFERENCES employees(employee_id)
	);


--fact tables
CREATE TABLE attendance(
	attend_id INT PRIMARY KEY,	
	attendance_date DATE,	
	time_in DATETIME,	
	time_out DATETIME,	
	employee_id INT,
	FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
	);
CREATE TABLE leave(
	leave_id INT PRIMARY KEY,
	approval_status NVARCHAR(50),	
	type_of_leave NVARCHAR(100),	
	leave_start_date DATE,	
	leave_end_date DATE,	
	employee_id INT REFERENCES employees(employee_id)
	);
CREATE TABLE payroll(
	payroll_id INT PRIMARY KEY,	
	payroll_date DATE,	
	salary_amount DECIMAL,	
	tax_deduction DECIMAL,	
	allowance DECIMAL,	
	bonus DECIMAL,	
	employee_id INT REFERENCES employees(employee_id)
	);
CREATE TABLE evaluations(
	evaluation_id INT PRIMARY KEY,	
	evaluator_id INT,	
	employee_id INT,
	score INT,	
	evaluation_date DATE,	
	FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
	);
CREATE TABLE benefits(
	benefit_id INT PRIMARY KEY,	
	employee_id INT,
	benefits_type NVARCHAR(200),
	benefits_desc NVARCHAR(200),	
	eligiablity_criteria NVARCHAR(50),	
	FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
	);

CREATE TABLE empEmergency(
    employee_id INT NOT NULL,
    emergency_id INT NOT NULL,  -- serial number per employee
    emergency_name NVARCHAR(100) NOT NULL,
    relationship NVARCHAR(50),
    phone_number NVARCHAR(50),
    PRIMARY KEY (employee_id, emergency_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
ALTER TABLE benefits ALTER COLUMN eligiablity_criteria VARCHAR(200);
ALTER TABLE departments ALTER COLUMN head_id DECIMAL;
ALTER TABLE jobs ALTER COLUMN hourly_rate decimal;
DROP TABLE empEmergency;

--M-to-M tables
CREATE TABLE evaluations_comments(
	--comment_id INT PRIMARY KEY IDENTITY(1,1),
	evaluation_id INT,	
	comment_id INT NOT NULL,  -- serial number per employee
	comments NVARCHAR(200), 
	PRIMARY KEY (evaluation_id, comment_id),
	FOREIGN KEY (evaluation_id)  REFERENCES evaluations(evaluation_id)
	);
DROP TABLE evaluations_comments
CREATE TABLE employees_evaluations(
	evaluation_id INT,	
	employee_id INT,
	PRIMARY KEY (evaluation_id, employee_id),
	FOREIGN KEY (evaluation_id)  REFERENCES evaluations(evaluation_id), 
	FOREIGN KEY (employee_id)  REFERENCES employees(employee_id)
	);
CREATE TABLE employees_programs(
	employee_id INT,
	program_id INT, 
	PRIMARY KEY (program_id, employee_id),
	FOREIGN KEY (program_id)  REFERENCES programTrainings(training_id), 
	FOREIGN KEY (employee_id)  REFERENCES employees(employee_id)
	);
CREATE TABLE employees_projects(
	employee_id INT,
	project_id INT, 
	PRIMARY KEY (project_id, employee_id),
	FOREIGN KEY (project_id)  REFERENCES projects(project_id), 
	FOREIGN KEY (employee_id)  REFERENCES employees(employee_id)
	);
DROP TABLE employees_projects

--Alter constraints (FKs)
ALTER TABLE departments ADD CONSTRAINT FK_dept_head FOREIGN KEY (head_id) REFERENCES employees(employee_id);

ALTER TABLE jobs ADD CONSTRAINT FK_job_dept FOREIGN KEY (dept_id) REFERENCES departments(dept_id);

ALTER TABLE employees ADD 
	CONSTRAINT FK_emp_dept FOREIGN KEY (dept_id) REFERENCES departments(dept_id),
    CONSTRAINT FK_emp_job FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    CONSTRAINT FK_emp_super FOREIGN KEY (supervisor_id) REFERENCES employees(employee_id);



------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
BULK INSERT projects
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\project.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM projects;
--TRUNCATE TABLE projects;  --error due to foreign key existance
DELETE FROM projects;


BULK INSERT programTrainings
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\traning_programs.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM programTrainings;
DELETE FROM programTrainings;


BULK INSERT departments
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\dept.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM departments;
DELETE FROM departments;

BULK INSERT jobs
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\jobs.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM jobs;
DROP TABLE jobs

BULK INSERT jobs
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\jobs.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2,
    KEEPNULLS
);

BULK INSERT employees
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\employee.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM employees;


BULK INSERT attendance
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\attendance.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM attendance;


BULK INSERT leave
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\leave.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM leave;


BULK INSERT payroll
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\payroll.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM payroll;


BULK INSERT evaluations
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\evaluation.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM evaluations;


BULK INSERT benefits
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\benefits.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM benefits;




CREATE TABLE empEmergency_staging(
    employee_id INT NOT NULL,
    emergency_name NVARCHAR(100) NOT NULL,
    relationship NVARCHAR(50),
    phone_number NVARCHAR(50)
);
BULK INSERT empEmergency_staging
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\emergency.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
INSERT INTO empEmergency (employee_id, emergency_id, emergency_name, relationship, phone_number)
SELECT 
    employee_id,
    ROW_NUMBER() OVER (PARTITION BY employee_id ORDER BY emergency_name) AS emergency_id,
    emergency_name,
    relationship,
    phone_number
FROM empEmergency_staging;
SELECT * FROM empEmergency
ORDER BY employee_id, emergency_id;
DELETE FROM empEmergency



CREATE TABLE comments_staging(
	--comment_id INT PRIMARY KEY IDENTITY(1,1),
	evaluation_id INT,	
	comments NVARCHAR(200)
	);

BULK INSERT comments_staging --evaluations_comments
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\evaluation_comments.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

INSERT INTO evaluations_comments(evaluation_id, comment_id, comments)
SELECT evaluation_id, ROW_NUMBER() OVER(PARTITION BY evaluation_id ORDER BY comments) comment_id, comments
FROM comments_staging;


SELECT * FROM evaluations_comments
ORDER BY evaluation_id, comment_id
;

SELECT count(*) FROM leave





BULK INSERT employees_evaluations
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\employee_evaluation.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM employees_evaluations;





BULK INSERT employees_programs
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\program_emp.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

SELECT * FROM employees_programs;





BULK INSERT employees_projects
FROM 'E:\Portfolio\9. HR & Payroll System Dashboard\Generate dataset\employees_projects.csv'
WITH (
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);
SELECT * FROM employees_projects

